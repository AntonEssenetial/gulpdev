// module__lightbox
(function() {


    // Lightbox
    function lightBox() {
        $('.jsLightBox').simpleLightbox({
            nextOnImageClick: false
        });
    }

    //lightBox()


})();
