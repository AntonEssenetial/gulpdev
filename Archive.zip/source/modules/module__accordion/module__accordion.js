// module__accordion
(function() {


    // Accordion 
    function navGoco(accordion) {
        var jsAccordion = $(accordion);
        jsAccordion.navgoco({accordion: true});
    }

    navGoco('.jsAccordion');


})();
