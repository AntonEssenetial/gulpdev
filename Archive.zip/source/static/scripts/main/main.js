'use strict';

svg4everybody();

// Modules
//= require source/modules/**/!(_)*.js
